import { useState, useEffect } from "react";
import LayoutShell from "@/components/layout-shell";
import { useProducts, useCreateProduct, useDeleteProduct, useScript, useUpdateScript } from "@/hooks/use-dashboard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Code, ShieldCheck, Lock, FileCode, Copy, Download, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";

export default function ProductsPage() {
  const { data: products, isLoading } = useProducts();
  const createProduct = useCreateProduct();
  const deleteProduct = useDeleteProduct();
  const [newProductName, setNewProductName] = useState("");
  const [newProductDesc, setNewProductDesc] = useState("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const handleCreate = async () => {
    await createProduct.mutateAsync({ 
      name: newProductName, 
      description: newProductDesc,
      version: "1.0.0",
      isEnabled: true 
    });
    setIsCreateOpen(false);
    setNewProductName("");
    setNewProductDesc("");
  };

  return (
    <LayoutShell>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold font-display">Products & Scripts</h2>
          <p className="text-muted-foreground">Manage your software catalog and source code.</p>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-white shadow-[0_0_15px_rgba(206,14,61,0.3)]">
              <Plus className="w-4 h-4 mr-2" />
              Create Product
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Product</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Product Name</Label>
                <Input 
                  placeholder="e.g. Shinra Hub" 
                  value={newProductName}
                  onChange={(e) => setNewProductName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Input 
                  placeholder="Universal script for..." 
                  value={newProductDesc}
                  onChange={(e) => setNewProductDesc(e.target.value)}
                />
              </div>
              <Button 
                className="w-full" 
                onClick={handleCreate}
                disabled={createProduct.isPending || !newProductName}
              >
                {createProduct.isPending ? "Creating..." : "Create Product"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {products?.map((product) => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onDelete={() => deleteProduct.mutate(product.id)}
            />
          ))}
          {products?.length === 0 && (
            <div className="col-span-full text-center py-12 text-muted-foreground border border-dashed border-border rounded-lg">
              No products found. Create your first product to get started.
            </div>
          )}
        </div>
      )}
    </LayoutShell>
  );
}

function ProductCard({ product, onDelete }: { product: any, onDelete: () => void }) {
  const [isScriptOpen, setIsScriptOpen] = useState(false);

  return (
    <Card className="bg-card/50 backdrop-blur border-white/5 hover:border-primary/30 transition-all group">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <CardTitle className="font-display tracking-wide">{product.name}</CardTitle>
            <CardDescription>{product.description || "No description provided"}</CardDescription>
          </div>
          <Badge variant="outline" className={product.isEnabled ? "border-green-500/50 text-green-500" : "border-red-500/50 text-red-500"}>
            {product.version}
          </Badge>
        </div>
      </CardHeader>
      <CardFooter className="flex justify-between border-t border-white/5 pt-4">
        <Dialog open={isScriptOpen} onOpenChange={setIsScriptOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <Code className="w-4 h-4" /> Script
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl h-[80vh] flex flex-col bg-[#0d0d0d] border-white/10">
            <DialogHeader>
              <DialogTitle className="font-display text-xl flex items-center gap-2">
                <FileCode className="w-5 h-5 text-primary" />
                Script Editor: {product.name}
              </DialogTitle>
            </DialogHeader>
            <ScriptEditor productId={product.id} />
          </DialogContent>
        </Dialog>

        <Button 
          variant="ghost" 
          size="sm" 
          className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
          onClick={() => {
            if (confirm("Are you sure you want to delete this product?")) onDelete();
          }}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}

function ScriptEditor({ productId }: { productId: number }) {
  const { data: script, isLoading } = useScript(productId);
  const updateScript = useUpdateScript();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const [content, setContent] = useState("");
  const [isObfuscated, setIsObfuscated] = useState(false);
  const [copied, setCopied] = useState(false);

  const tier = (user as any)?.tier || 'free';
  const limits: Record<string, number> = { free: 10, pro: 50, enterprise: 150 };
  const limit = limits[tier] || 10;

  // Sync state when data loads
  useEffect(() => {
    if (script) {
      setContent(script.content);
      setIsObfuscated(script.isObfuscated || false);
    }
  }, [script]);

  const handleSave = async () => {
    try {
      await updateScript.mutateAsync({ productId, content, isObfuscated });
      toast({
        title: "Success",
        description: "Script saved and encrypted successfully.",
      });
    } catch (error: any) {
      console.error("Failed to save script:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to save script.",
        variant: "destructive",
      });
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    toast({
      title: "Copied",
      description: "Script copied to clipboard.",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `script_${productId}.lua`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({
      title: "Downloaded",
      description: "Script file has been generated.",
    });
  };

  if (isLoading) return <div className="flex-1 flex items-center justify-center"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="flex-1 flex flex-col gap-4 overflow-hidden">
      <div className="flex items-center justify-between px-1 flex-wrap gap-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <Switch 
              id="obfuscate" 
              checked={isObfuscated} 
              onCheckedChange={setIsObfuscated} 
            />
            <Label htmlFor="obfuscate" className="flex items-center gap-2 cursor-pointer text-sm">
              <ShieldCheck className="w-4 h-4 text-primary" />
              Enable VM & Roblox Protection
            </Label>
          </div>
          <Badge variant="outline" className="bg-primary/10 border-primary text-primary">
            SHINRAGUARD SVM V4.5
          </Badge>
          <Badge variant="secondary" className="text-[10px] uppercase">
            Plan: {tier} ({limit} limit)
          </Badge>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={handleCopy} className="gap-2">
            {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
            Copy
          </Button>
          <Button variant="outline" size="sm" onClick={handleDownload} className="gap-2">
            <Download className="w-4 h-4" />
            Save as File
          </Button>
          <Button onClick={handleSave} disabled={updateScript.isPending} className="gap-2">
            {updateScript.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
            Save & Encrypt
          </Button>
        </div>
      </div>

      <Textarea 
        className="flex-1 font-mono text-xs bg-[#1e1e1e] border-0 resize-none p-4 leading-relaxed text-blue-100 selection:bg-primary/30 focus-visible:ring-0 min-h-[300px]"
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="-- Paste your Lua script here..."
        spellCheck={false}
      />
      <div className="text-xs text-muted-foreground flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          Ready to deploy. Script is served encrypted to loaders.
        </div>
        <div className="text-[10px] uppercase opacity-50">
          Shinraguard Secure SVM V4.5
        </div>
      </div>
    </div>
  );
}
