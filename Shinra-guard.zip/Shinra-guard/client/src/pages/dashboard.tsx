import { useProducts, useLicenses, useLogs, useHwidBans } from "@/hooks/use-dashboard";
import LayoutShell from "@/components/layout-shell";
import { StatsCard } from "@/components/stats-card";
import { Activity, Users, ShieldAlert, Key, Zap, Check } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

function PlanCard({ title, price, features, isPopular }: { title: string, price: string, features: string[], isPopular?: boolean }) {
  const handleGetPlan = () => {
    window.open("https://discord.gg/hgn7Q8DUGu", "_blank");
  };

  return (
    <Card className={cn("bg-card/50 backdrop-blur border-white/5 h-full flex flex-col", isPopular && "border-primary/50 shadow-[0_0_15px_rgba(206,14,61,0.1)]")}>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl font-display">{title}</CardTitle>
          {isPopular && <Badge className="bg-primary text-primary-foreground">Popular</Badge>}
        </div>
        <CardDescription className="text-2xl font-bold text-foreground mt-2">{price}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <ul className="space-y-3">
          {features.map((f, i) => (
            <li key={i} className="text-sm flex items-center gap-2 text-muted-foreground">
              <Check className="w-4 h-4 text-primary" />
              {f}
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter className="mt-auto pt-4">
        <Button className="w-full h-10" variant={isPopular ? "default" : "outline"} onClick={handleGetPlan}>Get Plan</Button>
      </CardFooter>
    </Card>
  );
}

export default function Dashboard() {
  const { data: products } = useProducts();
  const { data: licenses } = useLicenses();
  const { data: logs } = useLogs();
  const { data: bans } = useHwidBans();
  const { user } = useAuth();
  const { toast } = useToast();
  const [inviteCode, setInviteCode] = useState("");
  const [isRedeeming, setIsRedeeming] = useState(false);

  const handleRedeemInvite = async () => {
    if (!inviteCode) return;
    try {
      setIsRedeeming(true);
      const res = await apiRequest("POST", "/api/user/redeem", { code: inviteCode });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || "Invalid invite code");
      }
      toast({ title: "Success", description: "Invite redeemed successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setInviteCode("");
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setIsRedeeming(false);
    }
  };

  // Calculate stats
  const totalProducts = products?.length || 0;
  const totalLicenses = licenses?.length || 0;
  const activeLicenses = licenses?.filter(l => l.status === 'active').length || 0;
  const totalBans = bans?.length || 0;
  const recentExecutions = logs?.filter(l => l.status === 'success').length || 0;

  // Chart data
  const chartData = logs?.reduce((acc, log) => {
    if (!log.executedAt) return acc;
    const date = format(new Date(log.executedAt), 'MMM dd');
    const existing = acc.find(item => item.date === date);
    if (existing) {
      existing.executions++;
    } else {
      acc.push({ date, executions: 1 });
    }
    return acc;
  }, [] as { date: string, executions: number }[]).slice(-7).reverse() || [];

  return (
    <LayoutShell>
      <div className="flex justify-between items-end flex-wrap gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/50">Overview</h2>
          <p className="text-muted-foreground">Welcome back to Shinraguard.</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Badge variant="outline" className="h-8">System: Online</Badge>
          <Badge variant="outline" className="h-8 text-primary border-primary/50">Shinraguard v1.4.2</Badge>
        </div>
      </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <StatsCard
            title="Total Products"
            value={totalProducts}
            icon={Zap}
            description="Active scripts deployed"
            className="min-h-[100px] w-full"
          />
          <StatsCard
            title="Active Licenses"
            value={activeLicenses}
            icon={Key}
            description={`${totalLicenses} keys generated`}
            className="min-h-[100px] w-full"
          />
          <StatsCard
            title="Recent Executions"
            value={recentExecutions}
            icon={Activity}
            description="Success loads"
            className="min-h-[100px] w-full"
          />
          <StatsCard
            title="HWID Bans"
            value={totalBans}
            icon={ShieldAlert}
            description="Blacklisted IDs"
            className="border-destructive/20 min-h-[100px] w-full"
          />
        </div>

      <div className="space-y-4 mb-8">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <h3 className="text-xl font-semibold font-display">Premium Tiers</h3>
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <input 
              type="text" 
              placeholder="Enter invite link/code" 
              className="bg-card/50 border border-white/5 rounded-md px-3 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-primary w-full sm:w-64"
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
            />
            <Button variant="outline" size="sm" onClick={handleRedeemInvite} disabled={isRedeeming} className="w-full sm:w-auto">
              {isRedeeming ? "Redeeming..." : "Redeem Invite"}
            </Button>
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          <PlanCard 
            title="Free" 
            price="$0" 
            features={["10 Obfuscations/mo", "Direct Provider", "Basic Protection", "Community Support"]} 
          />
          <PlanCard 
            title="Pro" 
            price="$5/mo" 
            isPopular
            features={["50 Obfuscations/mo", "Linkvertise/Direct", "Key System", "HWID Lock", "Anti-Tamper Pro"]} 
          />
          <PlanCard 
            title="Enterprise" 
            price="$15/mo" 
            features={["150 Obfuscations/mo", "All Providers (Lootlabs)", "Custom Watermark", "SVM V4.5+ Emulation", "24/7 Priority"]} 
          />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7 mb-8">
        <Card className="col-span-1 md:col-span-2 lg:col-span-4 bg-card/50 backdrop-blur border-white/5">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="font-display text-lg">Execution Activity</CardTitle>
            <Button variant="ghost" size="sm" className="h-8 text-xs text-muted-foreground hover:text-primary transition-colors hidden sm:flex">
              View All Logs
            </Button>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[250px] sm:h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis 
                    dataKey="date" 
                    stroke="#888888" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                  <YAxis 
                    stroke="#888888" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(value) => `${value}`} 
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', color: '#fff', fontSize: '12px' }}
                    itemStyle={{ color: '#ce0e3d' }}
                    cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                  />
                  <Bar 
                    dataKey="executions" 
                    fill="#ce0e3d" 
                    radius={[4, 4, 0, 0]} 
                    className="fill-primary"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1 md:col-span-2 lg:col-span-3 bg-card/50 backdrop-blur border-white/5 h-full overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="font-display text-lg">Live Feed</CardTitle>
            <Badge variant="outline" className="text-[10px] uppercase tracking-wider animate-pulse border-primary/50 text-primary">Live</Badge>
          </CardHeader>
          <CardContent className="h-[250px] sm:h-[300px] overflow-y-auto pr-2 custom-scrollbar">
            <div className="space-y-6">
              {logs?.slice(0, 10).map((log) => (
                <div key={log.id} className="flex items-center">
                  <span className={cn(
                    "flex h-2 w-2 rounded-full mr-3 sm:mr-4 flex-shrink-0", 
                    log.status === 'success' ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]" : "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]"
                  )} />
                  <div className="flex-1 space-y-1 overflow-hidden">
                    <p className="text-xs sm:text-sm font-medium leading-none font-mono truncate">
                      {log.hwid?.substring(0, 16) || "Unknown HWID"}
                    </p>
                    <p className="text-[9px] sm:text-[10px] text-muted-foreground uppercase truncate">
                      {log.executedAt && format(new Date(log.executedAt), "HH:mm:ss")} • {log.details}
                    </p>
                  </div>
                  <div className="ml-2 font-medium text-[9px] sm:text-[10px] bg-white/5 px-1.5 sm:px-2 py-0.5 rounded uppercase tracking-tighter flex-shrink-0">
                    {log.status}
                  </div>
                </div>
              ))}
              {(!logs || logs.length === 0) && (
                <p className="text-sm text-muted-foreground text-center py-4">Waiting for connections...</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </LayoutShell>
  );
}
