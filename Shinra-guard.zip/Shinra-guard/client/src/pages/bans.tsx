import LayoutShell from "@/components/layout-shell";
import { useHwidBans, useCreateHwidBan, useDeleteHwidBan } from "@/hooks/use-dashboard";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { Trash2, ShieldBan } from "lucide-react";
import { format } from "date-fns";

export default function BansPage() {
  const { data: bans, isLoading } = useHwidBans();
  const createBan = useCreateHwidBan();
  const deleteBan = useDeleteHwidBan();
  const [hwid, setHwid] = useState("");
  const [reason, setReason] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const handleBan = async () => {
    if (!hwid) return;
    await createBan.mutateAsync({ hwid, reason });
    setIsOpen(false);
    setHwid("");
    setReason("");
  };

  return (
    <LayoutShell>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold font-display text-destructive">HWID Blacklist</h2>
          <p className="text-muted-foreground">Permanently ban devices from accessing your scripts.</p>
        </div>

        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button variant="destructive" className="shadow-[0_0_15px_rgba(239,68,68,0.3)]">
              <ShieldBan className="w-4 h-4 mr-2" />
              Ban HWID
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Blacklist Hardware ID</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>HWID String</Label>
                <Input 
                  placeholder="Paste HWID here..." 
                  value={hwid}
                  onChange={(e) => setHwid(e.target.value)}
                  className="font-mono text-xs"
                />
              </div>
              <div className="space-y-2">
                <Label>Reason (Optional)</Label>
                <Input 
                  placeholder="e.g. Chargeback, Leaking" 
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
              </div>
              <Button 
                variant="destructive"
                className="w-full" 
                onClick={handleBan}
                disabled={createBan.isPending || !hwid}
              >
                {createBan.isPending ? "Banning..." : "Confirm Ban"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border border-white/5 bg-card/50 backdrop-blur overflow-hidden">
        <Table>
          <TableHeader className="bg-white/5">
            <TableRow className="hover:bg-transparent border-white/5">
              <TableHead className="font-mono">HWID</TableHead>
              <TableHead>REASON</TableHead>
              <TableHead>BANNED AT</TableHead>
              <TableHead className="text-right">ACTIONS</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8">Loading...</TableCell>
              </TableRow>
            ) : bans?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No bans found.</TableCell>
              </TableRow>
            ) : (
              bans?.map((ban) => (
                <TableRow key={ban.id} className="border-white/5 hover:bg-white/5">
                  <TableCell className="font-mono text-xs text-muted-foreground">{ban.hwid}</TableCell>
                  <TableCell>{ban.reason || "No reason specified"}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {ban.bannedAt && format(new Date(ban.bannedAt), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-muted-foreground hover:text-white"
                      onClick={() => {
                        if (confirm("Unban this HWID?")) deleteBan.mutate(ban.id);
                      }}
                    >
                      <Trash2 className="w-4 h-4 mr-2" /> Unban
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </LayoutShell>
  );
}
