import { z } from 'zod';
import { insertProductSchema, insertLicenseSchema, insertHwidBanSchema, insertScriptSchema, products, licenses, hwidBans, scripts, executionLogs } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  })
};

export const api = {
  // --- ADMIN / DASHBOARD ENDPOINTS ---
  products: {
    list: {
      method: 'GET' as const,
      path: '/api/products',
      responses: {
        200: z.array(z.custom<typeof products.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/products',
      input: insertProductSchema,
      responses: {
        201: z.custom<typeof products.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/products/:id',
      input: insertProductSchema.partial(),
      responses: {
        200: z.custom<typeof products.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/products/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  
  licenses: {
    list: {
      method: 'GET' as const,
      path: '/api/licenses',
      responses: {
        200: z.array(z.custom<typeof licenses.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/licenses',
      input: insertLicenseSchema,
      responses: {
        201: z.custom<typeof licenses.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/licenses/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    resetHwid: {
      method: 'POST' as const,
      path: '/api/licenses/:id/reset-hwid',
      responses: {
        200: z.custom<typeof licenses.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    }
  },

  hwidBans: {
    list: {
      method: 'GET' as const,
      path: '/api/hwid-bans',
      responses: {
        200: z.array(z.custom<typeof hwidBans.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/hwid-bans',
      input: insertHwidBanSchema,
      responses: {
        201: z.custom<typeof hwidBans.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/hwid-bans/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  scripts: {
    get: {
      method: 'GET' as const,
      path: '/api/products/:productId/script',
      responses: {
        200: z.custom<typeof scripts.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'POST' as const, // UPSERT basically
      path: '/api/products/:productId/script',
      input: z.object({ content: z.string(), isObfuscated: z.boolean().optional() }),
      responses: {
        200: z.custom<typeof scripts.$inferSelect>(),
      },
    },
  },

  logs: {
    list: {
      method: 'GET' as const,
      path: '/api/logs',
      responses: {
        200: z.array(z.custom<typeof executionLogs.$inferSelect>()),
      },
    }
  },

  // --- PUBLIC / LOADER ENDPOINTS ---
  loader: {
    authenticate: {
      method: 'POST' as const,
      path: '/api/loader/authenticate',
      input: z.object({
        key: z.string(),
        hwid: z.string(),
        executor: z.string().optional()
      }),
      responses: {
        200: z.object({
          valid: z.boolean(),
          script: z.string().optional(),
          message: z.string().optional()
        }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
