import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertProduct, type InsertLicense, type InsertHwidBan } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

// --- PRODUCTS HOOKS ---
export function useProducts() {
  return useQuery({
    queryKey: [api.products.list.path],
    queryFn: async () => {
      const res = await fetch(api.products.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch products");
      return api.products.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateProduct() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertProduct) => {
      const res = await fetch(api.products.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create product");
      return api.products.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.products.list.path] });
      toast({ title: "Success", description: "Product created successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });
}

export function useDeleteProduct() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.products.delete.path, { id });
      const res = await fetch(url, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Failed to delete product");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.products.list.path] });
      toast({ title: "Success", description: "Product deleted" });
    },
  });
}

// --- LICENSES HOOKS ---
export function useLicenses() {
  return useQuery({
    queryKey: [api.licenses.list.path],
    queryFn: async () => {
      const res = await fetch(api.licenses.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch licenses");
      return api.licenses.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateLicense() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertLicense) => {
      const res = await fetch(api.licenses.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create license");
      return api.licenses.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.licenses.list.path] });
      toast({ title: "Success", description: "License key generated" });
    },
  });
}

export function useDeleteLicense() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.licenses.delete.path, { id });
      const res = await fetch(url, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Failed to delete license");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.licenses.list.path] });
      toast({ title: "Success", description: "License deleted" });
    },
  });
}

export function useResetHwid() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.licenses.resetHwid.path, { id });
      const res = await fetch(url, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Failed to reset HWID");
      return api.licenses.resetHwid.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.licenses.list.path] });
      toast({ title: "Success", description: "HWID reset successfully" });
    },
  });
}

// --- HWID BANS HOOKS ---
export function useHwidBans() {
  return useQuery({
    queryKey: [api.hwidBans.list.path],
    queryFn: async () => {
      const res = await fetch(api.hwidBans.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch HWID bans");
      return api.hwidBans.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateHwidBan() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertHwidBan) => {
      const res = await fetch(api.hwidBans.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to ban HWID");
      return api.hwidBans.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.hwidBans.list.path] });
      toast({ title: "Success", description: "HWID banned" });
    },
  });
}

export function useDeleteHwidBan() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.hwidBans.delete.path, { id });
      const res = await fetch(url, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Failed to unban HWID");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.hwidBans.list.path] });
      toast({ title: "Success", description: "HWID unbanned" });
    },
  });
}

// --- SCRIPT HOOKS ---
export function useScript(productId: number) {
  return useQuery({
    queryKey: [api.scripts.get.path, productId],
    queryFn: async () => {
      const url = buildUrl(api.scripts.get.path, { productId });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch script");
      return api.scripts.get.responses[200].parse(await res.json());
    },
    enabled: !!productId,
  });
}

export function useUpdateScript() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ productId, content, isObfuscated }: { productId: number, content: string, isObfuscated: boolean }) => {
      const url = buildUrl(api.scripts.update.path, { productId });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, isObfuscated }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update script");
      return api.scripts.update.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.scripts.get.path, variables.productId] });
      toast({ title: "Success", description: "Script updated and encrypted" });
    },
  });
}

// --- LOGS HOOKS ---
export function useLogs() {
  return useQuery({
    queryKey: [api.logs.list.path],
    queryFn: async () => {
      const res = await fetch(api.logs.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch logs");
      return api.logs.list.responses[200].parse(await res.json());
    },
  });
}
