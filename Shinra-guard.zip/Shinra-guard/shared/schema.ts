import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  email: text("email"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  profileImageUrl: text("profile_image_url"),
  tier: text("tier").default("free"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ createdAt: true, updatedAt: true });
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// --- PRODUCTS / SCRIPTS ---
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  version: text("version").default("1.0.0"),
  isEnabled: boolean("is_enabled").default(true),
  tier: text("tier").default("free"), // free, pro, enterprise
  keySystemEnabled: boolean("key_system_enabled").default(false),
  keyProvider: text("key_provider").default("direct"), // direct, linkvertise, lootlabs, workink
  obfuscationLimit: integer("obfuscation_limit").default(10),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).omit({ id: true, createdAt: true });
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

// --- KEYS / AUTH ---
export const productKeys = pgTable("product_keys", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id).notNull(),
  key: text("key").notNull().unique(),
  hwid: text("hwid"),
  expiresAt: timestamp("expires_at"),
  tier: text("tier").default("free"),
  inviteUsed: boolean("invite_used").default(false),
  googleId: text("google_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductKeySchema = createInsertSchema(productKeys).omit({ id: true, createdAt: true });
export type ProductKey = typeof productKeys.$inferSelect;
export type InsertProductKey = z.infer<typeof insertProductKeySchema>;

// --- LICENSES / KEYS ---
export const licenses = pgTable("licenses", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(), // The actual license key
  productId: integer("product_id").references(() => products.id).notNull(),
  hwid: text("hwid"), // Bound HWID, null if unused
  status: text("status").default("active"), // active, banned, expired
  clientIp: text("client_ip"),
  lastUsedAt: timestamp("last_used_at"),
  expiresAt: timestamp("expires_at"), // Null for lifetime
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: text("created_by"), // Admin user ID
});

export const insertLicenseSchema = createInsertSchema(licenses).omit({ 
  id: true, 
  createdAt: true, 
  lastUsedAt: true,
  hwid: true,
  clientIp: true
});
export type License = typeof licenses.$inferSelect;
export type InsertLicense = z.infer<typeof insertLicenseSchema>;

// --- HWID BANS ---
export const hwidBans = pgTable("hwid_bans", {
  id: serial("id").primaryKey(),
  hwid: text("hwid").notNull().unique(),
  reason: text("reason"),
  bannedAt: timestamp("banned_at").defaultNow(),
  bannedBy: text("banned_by"), // Admin user ID
});

export const insertHwidBanSchema = createInsertSchema(hwidBans).omit({ id: true, bannedAt: true });
export type HwidBan = typeof hwidBans.$inferSelect;
export type InsertHwidBan = z.infer<typeof insertHwidBanSchema>;

// --- SCRIPT CONTENT (Encrypted/Obfuscated storage) ---
export const scripts = pgTable("scripts", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id).notNull().unique(), // One script per product usually
  content: text("content").notNull(), // Raw Lua content
  isObfuscated: boolean("is_obfuscated").default(false),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertScriptSchema = createInsertSchema(scripts).omit({ id: true, updatedAt: true });
export type Script = typeof scripts.$inferSelect;
export type InsertScript = z.infer<typeof insertScriptSchema>;

// --- EXECUTION LOGS ---
export const executionLogs = pgTable("execution_logs", {
  id: serial("id").primaryKey(),
  licenseId: integer("license_id").references(() => licenses.id),
  hwid: text("hwid"),
  ipAddress: text("ip_address"),
  status: text("status").notNull(), // success, failed, banned_hwid, invalid_key
  details: text("details"), // Optional error message or info
  executedAt: timestamp("executed_at").defaultNow(),
});

export type ExecutionLog = typeof executionLogs.$inferSelect;

// --- INVITES ---
export const invites = pgTable("invites", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  tier: text("tier").notNull().default("pro"),
  isUsed: boolean("is_used").default(false),
  usedBy: text("used_by"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInviteSchema = createInsertSchema(invites).omit({ id: true, createdAt: true, isUsed: true, usedBy: true });
export type Invite = typeof invites.$inferSelect;
export type InsertInvite = z.infer<typeof insertInviteSchema>;

// --- OBFUSCATION TRACKING ---
export const obfuscationLogs = pgTable("obfuscation_logs", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  month: text("month").notNull(), // YYYY-MM
  count: integer("count").default(0),
});

export type ObfuscationLog = typeof obfuscationLogs.$inferSelect;

// Key Check / Script Load Request (From Roblox)
export const scriptLoadRequestSchema = z.object({
  key: z.string().min(1),
  hwid: z.string().min(1),
  executor: z.string().optional(), // Synapse, Krnl, etc.
});
export type ScriptLoadRequest = z.infer<typeof scriptLoadRequestSchema>;

// Script Load Response (Encrypted)
export interface ScriptLoadResponse {
  valid: boolean;
  script?: string; // Encrypted script content
  message?: string;
}
