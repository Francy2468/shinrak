import LayoutShell from "@/components/layout-shell";
import { useLogs } from "@/hooks/use-dashboard";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function LogsPage() {
  const { data: logs, isLoading } = useLogs();

  return (
    <LayoutShell>
      <div className="mb-8">
        <h2 className="text-3xl font-bold font-display">Execution Logs</h2>
        <p className="text-muted-foreground">Audit trail of all script load attempts.</p>
      </div>

      <div className="rounded-md border border-white/5 bg-card/50 backdrop-blur overflow-hidden">
        <Table>
          <TableHeader className="bg-white/5">
            <TableRow className="hover:bg-transparent border-white/5">
              <TableHead>TIMESTAMP</TableHead>
              <TableHead>STATUS</TableHead>
              <TableHead>IP ADDRESS</TableHead>
              <TableHead>HWID</TableHead>
              <TableHead>DETAILS</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8">Loading...</TableCell>
              </TableRow>
            ) : logs?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No logs found.</TableCell>
              </TableRow>
            ) : (
              logs?.map((log) => (
                <TableRow key={log.id} className="border-white/5 hover:bg-white/5">
                  <TableCell className="text-xs font-mono text-muted-foreground">
                    {log.executedAt && format(new Date(log.executedAt), "MMM d, HH:mm:ss")}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={
                      log.status === 'success' ? "border-green-500/50 text-green-500" : "border-red-500/50 text-red-500"
                    }>
                      {log.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono text-xs">{log.ipAddress}</TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground max-w-[150px] truncate" title={log.hwid || ''}>
                    {log.hwid}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {log.details || "-"}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </LayoutShell>
  );
}
