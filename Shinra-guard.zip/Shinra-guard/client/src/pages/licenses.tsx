import LayoutShell from "@/components/layout-shell";
import { useLicenses, useCreateLicense, useDeleteLicense, useResetHwid, useProducts } from "@/hooks/use-dashboard";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { Copy, RefreshCw, Trash2, Plus, Search } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function LicensesPage() {
  const { data: licenses, isLoading } = useLicenses();
  const { data: products } = useProducts();
  const createLicense = useCreateLicense();
  const deleteLicense = useDeleteLicense();
  const resetHwid = useResetHwid();
  const { toast } = useToast();

  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const handleCreate = async () => {
    if (!selectedProduct) return;
    await createLicense.mutateAsync({
      key: `SHINRA-${Math.random().toString(36).substring(2, 10).toUpperCase()}-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      productId: parseInt(selectedProduct),
      status: "active",
      expiresAt: null // Lifetime for now
    });
    setIsCreateOpen(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied", description: "License key copied to clipboard" });
  };

  const filteredLicenses = licenses?.filter(l => 
    l.key.toLowerCase().includes(searchTerm.toLowerCase()) || 
    l.hwid?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <LayoutShell>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-bold font-display">License Management</h2>
          <p className="text-muted-foreground">Issue and manage access keys.</p>
        </div>

        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search keys..." 
              className="pl-9 w-[250px] bg-card/50"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-white shadow-[0_0_15px_rgba(206,14,61,0.3)]">
                <Plus className="w-4 h-4 mr-2" />
                Generate Key
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Generate License</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Select Product</Label>
                  <Select onValueChange={setSelectedProduct} value={selectedProduct}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a product" />
                    </SelectTrigger>
                    <SelectContent>
                      {products?.map(p => (
                        <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Duration</Label>
                  <Select defaultValue="lifetime">
                    <SelectTrigger>
                      <SelectValue placeholder="Duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="lifetime">Lifetime</SelectItem>
                      <SelectItem value="30d" disabled>30 Days (Coming soon)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button 
                  className="w-full" 
                  onClick={handleCreate}
                  disabled={createLicense.isPending || !selectedProduct}
                >
                  {createLicense.isPending ? "Generating..." : "Generate Key"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="rounded-md border border-white/5 bg-card/50 backdrop-blur overflow-hidden">
        <Table>
          <TableHeader className="bg-white/5">
            <TableRow className="hover:bg-transparent border-white/5">
              <TableHead className="font-mono">KEY</TableHead>
              <TableHead>PRODUCT</TableHead>
              <TableHead>HWID</TableHead>
              <TableHead>STATUS</TableHead>
              <TableHead>CREATED</TableHead>
              <TableHead className="text-right">ACTIONS</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">Loading...</TableCell>
              </TableRow>
            ) : filteredLicenses?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No licenses found.</TableCell>
              </TableRow>
            ) : (
              filteredLicenses?.map((license) => (
                <TableRow key={license.id} className="border-white/5 hover:bg-white/5">
                  <TableCell className="font-mono text-xs md:text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-primary">{license.key}</span>
                      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyToClipboard(license.key)}>
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </TableCell>
                  <TableCell>{products?.find(p => p.id === license.productId)?.name || "Unknown"}</TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {license.hwid ? (
                      <span className="truncate max-w-[150px] block" title={license.hwid}>{license.hwid}</span>
                    ) : (
                      <span className="text-white/30 italic">Unbound</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={
                      license.status === 'active' ? "border-green-500/50 text-green-500" : "border-red-500/50 text-red-500"
                    }>
                      {license.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {license.createdAt && format(new Date(license.createdAt), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        title="Reset HWID"
                        onClick={() => resetHwid.mutate(license.id)}
                        disabled={!license.hwid}
                      >
                        <RefreshCw className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className="text-destructive hover:bg-destructive/10"
                        title="Delete License"
                        onClick={() => {
                          if (confirm("Revoke this license?")) deleteLicense.mutate(license.id);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </LayoutShell>
  );
}
