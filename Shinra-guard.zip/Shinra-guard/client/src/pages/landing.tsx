import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Zap, Lock, Code2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function LandingPage() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden font-sans">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-grid-pattern opacity-20 pointer-events-none" />
      <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-primary/10 to-transparent pointer-events-none" />
      <div className="absolute -top-[200px] -right-[200px] w-[600px] h-[600px] bg-primary/20 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute -bottom-[200px] -left-[200px] w-[600px] h-[600px] bg-purple-600/20 blur-[120px] rounded-full pointer-events-none" />

      {/* Nav */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center font-display font-bold">S</div>
          <span className="text-xl font-bold font-display tracking-widest">SHINRA</span>
        </div>
        <div>
          {isLoading ? (
            <div className="w-24 h-10 bg-white/5 animate-pulse rounded" />
          ) : isAuthenticated ? (
            <Link href="/dashboard">
              <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10">
                Dashboard <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          ) : (
            <a href="/api/login">
              <Button className="bg-white text-black hover:bg-gray-200 font-semibold">
                Login
              </Button>
            </a>
          )}
        </div>
      </nav>

      {/* Hero */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-20 pb-32 text-center md:text-left flex flex-col md:flex-row items-center">
        <div className="md:w-1/2 space-y-8">
          <div className="inline-flex items-center px-3 py-1 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-medium tracking-wide uppercase mb-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <span className="relative flex h-2 w-2 mr-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            System Online
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold font-display leading-tight tracking-tight animate-in fade-in slide-in-from-bottom-8 duration-700 delay-100">
            NEXT GEN <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-purple-500 to-white">PROTECTION</span>
          </h1>
          
          <p className="text-lg text-muted-foreground max-w-xl animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
            Enterprise-grade obfuscation and licensing for Lua scripts. Secure your intellectual property with Shinra's advanced authentication infrastructure.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 pt-4 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
            <a href="/api/login">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-white shadow-[0_0_20px_rgba(206,14,61,0.4)] px-8 py-6 text-lg">
                Start protecting <ArrowRight className="ml-2" />
              </Button>
            </a>
            <Button variant="outline" size="lg" className="border-white/10 hover:bg-white/5 px-8 py-6 text-lg">
              Documentation
            </Button>
          </div>
        </div>

        <div className="md:w-1/2 mt-16 md:mt-0 relative animate-in fade-in zoom-in duration-1000 delay-300">
          <div className="relative w-full max-w-lg mx-auto bg-black border border-white/10 rounded-xl overflow-hidden shadow-2xl shadow-primary/20">
            <div className="flex items-center px-4 py-3 border-b border-white/10 bg-white/5 gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/50" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
              <div className="w-3 h-3 rounded-full bg-green-500/50" />
              <div className="ml-4 text-xs font-mono text-muted-foreground">loader.lua</div>
            </div>
            <div className="p-6 font-mono text-sm space-y-2 text-blue-100/80">
              <div className="flex">
                <span className="text-muted-foreground w-8 select-none">1</span>
                <span><span className="text-purple-400">local</span> Shinra = <span className="text-yellow-300">loadstring</span>(game:<span className="text-yellow-300">HttpGet</span>(...))()</span>
              </div>
              <div className="flex">
                <span className="text-muted-foreground w-8 select-none">2</span>
                <span></span>
              </div>
              <div className="flex">
                <span className="text-muted-foreground w-8 select-none">3</span>
                <span>Shinra:<span className="text-blue-400">Authenticate</span>(<span className="text-green-400">"KEY-XXXX-XXXX"</span>)</span>
              </div>
              <div className="flex">
                <span className="text-muted-foreground w-8 select-none">4</span>
                <span></span>
              </div>
              <div className="flex">
                <span className="text-muted-foreground w-8 select-none">5</span>
                <span className="text-gray-500">-- Script loaded securely via encrypted stream</span>
              </div>
              <div className="flex">
                <span className="text-muted-foreground w-8 select-none">6</span>
                <span><span className="text-purple-400">print</span>(<span className="text-green-400">"Welcome, User"</span>)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="py-24 border-t border-white/5 bg-black/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={Lock}
              title="Encrypted Delivery"
              description="Scripts are never sent in plaintext. Our loader decrypts them in memory at runtime."
            />
            <FeatureCard 
              icon={Shield}
              title="HWID Locking"
              description="Keys are instantly bound to the user's hardware fingerprint to prevent sharing."
            />
            <FeatureCard 
              icon={Code2}
              title="Lua Obfuscation"
              description="Automatic heavy obfuscation applied to your scripts before they leave the server."
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description }: { icon: any, title: string, description: string }) {
  return (
    <div className="p-6 rounded-xl border border-white/5 bg-white/5 hover:border-primary/50 transition-colors group">
      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
        <Icon className="w-6 h-6 text-primary" />
      </div>
      <h3 className="text-xl font-bold font-display mb-2">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  );
}
